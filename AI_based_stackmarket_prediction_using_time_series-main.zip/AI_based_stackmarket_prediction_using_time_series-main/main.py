import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
from utils.helpers import preprocess_data
from models.lstm_model import train_lstm

def main():
    # Ensure directories exist
    os.makedirs('data', exist_ok=True)
    os.makedirs('results', exist_ok=True)
    
    try:
        # 1. Load and preprocess data
        df = preprocess_data("data/aapl.csv")
        
        # 2. Train-test split
        train_size = int(len(df) * 0.8)
        train = df.iloc[:train_size]
        test = df.iloc[train_size:]
        
        # 3. Train LSTM model
        print("Training LSTM model...")
        model, scaler = train_lstm(train[['Close']].values)
        
        # 4. Prepare test data
        test_scaled = scaler.transform(test[['Close']])
        
        # 5. Create sequences
        seq_length = 60
        X_test = []
        for i in range(seq_length, len(test_scaled)):
            X_test.append(test_scaled[i-seq_length:i])
        X_test = np.array(X_test)
        
        # 6. Make predictions
        print("Making predictions...")
        predictions = model.predict(X_test)
        predictions = scaler.inverse_transform(predictions)
        
        # 7. Plot results
        plt.figure(figsize=(12,6))
        plt.plot(test.index[seq_length:], test['Close'][seq_length:], label='Actual')
        plt.plot(test.index[seq_length:], predictions, label='Predicted')
        plt.title('AAPL Stock Price Prediction')
        plt.xlabel('Date')
        plt.ylabel('Price ($)')
        plt.legend()
        
        # 8. Save plot
        plt.savefig('results/predictions.png', bbox_inches='tight')
        print("✅ Results saved to results/predictions.png")
        plt.show()
        
    except Exception as e:
        print(f"❌ Error in main pipeline: {e}")

if __name__ == "__main__":
    main()