import pandas as pd
import numpy as np

def preprocess_data(filepath):
    """Loads and cleans the special CSV format"""
    try:
        # Load CSV skipping the metadata rows
        df = pd.read_csv(
            filepath,
            skiprows=2,          # Skip first 2 rows (header + metadata)
            header=0,            # Use first remaining row as header
            names=['Date','Close','High','Low','Open','Volume']  # Rename columns
        )
        
        # Convert Date to datetime
        df['Date'] = pd.to_datetime(df['Date'])
        df = df.set_index('Date')
        
        # Convert all numeric columns
        numeric_cols = ['Close','High','Low','Open','Volume']
        df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors='coerce')
        
        # Calculate indicators
        df['SMA_20'] = df['Close'].rolling(20).mean()
        df['RSI'] = calculate_rsi(df)
        
        return df.dropna()
        
    except Exception as e:
        print(f"❌ Error processing {filepath}: {e}")
        raise

def calculate_rsi(df, window=14):
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.rolling(window).mean()
    avg_loss = loss.rolling(window).mean()
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))