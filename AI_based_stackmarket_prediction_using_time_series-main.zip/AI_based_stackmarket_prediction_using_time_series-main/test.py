from utils.helpers import preprocess_data

df = preprocess_data("data/aapl.csv")
print("✅ Processed Data:")
print(df.head())
print("\nData types:")
print(df.dtypes)