# check_csv.py
import pandas as pd

def inspect_csv(filepath):
    try:
        df = pd.read_csv(filepath)
        print("✅ CSV loaded successfully")
        print("\nFirst 3 rows:")
        print(df.head(3))
        print("\nColumn names:")
        print(list(df.columns))
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    inspect_csv("data/aapl.csv")