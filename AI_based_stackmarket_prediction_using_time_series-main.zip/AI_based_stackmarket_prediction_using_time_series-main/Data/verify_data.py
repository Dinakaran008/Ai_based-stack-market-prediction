import pandas as pd

def verify_data(filepath):
    try:
        df = pd.read_csv(filepath)
        print(f"📊 Data Summary:")
        print(f"- Rows: {len(df)}")
        print(f"- Columns: {list(df.columns)}")
        print(f"- Date Range: {df['Date'].iloc[0]} to {df['Date'].iloc[-1]}")
        print("\nFirst 3 rows:")
        return df.head(3)
    except Exception as e:
        print(f"❌ Verification failed: {e}")
        return None

if __name__ == "__main__":
    verify_data("data/aapl.csv")