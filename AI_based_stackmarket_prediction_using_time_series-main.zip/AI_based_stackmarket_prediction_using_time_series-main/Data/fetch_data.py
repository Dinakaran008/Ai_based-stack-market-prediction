import yfinance as yf
import pandas as pd
import os
from datetime import datetime

def download_stock_data(
    ticker="AAPL",
    start="2015-01-01",
    end=datetime.now().strftime("%Y-%m-%d"),  # Automatically uses today as end date
    data_dir="data"
):
    """Downloads stock data and saves as CSV"""
    try:
        # Create data directory if missing
        os.makedirs(data_dir, exist_ok=True)
        
        # Download data
        print(f"Downloading {ticker} data from {start} to {end}...")
        data = yf.download(ticker, start=start, end=end, progress=False)
        
        # Save to CSV
        csv_path = f"{data_dir}/{ticker.lower()}.csv"
        data.to_csv(csv_path)
        print(f"✅ Data saved to {csv_path}")
        return csv_path
        
    except Exception as e:
        print(f"❌ Error downloading data: {e}")
        return None

if __name__ == "__main__":
    # Download multiple stocks
    for ticker in ["AAPL", "MSFT", "GOOG"]:
        download_stock_data(ticker=ticker)